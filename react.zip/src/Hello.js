import React from 'react';

function Hello() {
  return <div>안녕하세요</div>
}

export default Hello;